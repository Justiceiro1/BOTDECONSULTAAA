const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');

// Insira o token do seu bot do Telegram aqui
const token = '6598889487:AAGYY1G1rikqPWjUQuOcirRJ2VBldgu0Pvs';

// Crie uma instância do bot
const bot = new TelegramBot(token, { polling: true });

// Função para formatar o texto em negrito
const formatBold = (text) => {
  return `**${text}**`;
};

// Configuração dos comandos do bot
bot.onText(/\/cpf (.+)/, async (msg, match) => {
  const cpf = match[1];
  try {
    const response = await axios.get(`http://eazybusca.000webhostapp.com/cpf/${cpf}/GuardPro`);
    const data = response.data;
    const message = `
**CPF:** ${formatBold(data.cpf)}
**NOME:** ${formatBold(data.nome)}
NASCIMENTO: **${data.nascimento}**
MÃE: **${data.mae}**
PAI: **${data.pai || ''}**
SEXO: **${data.sexo}**
TELEFONE: **${data.telefone}**
TELEFONE2: **${data.telefone2 || ''}**
ENDEREÇO: **${data.endereco}**
    `;
    bot.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
  } catch (error) {
    bot.sendMessage(msg.chat.id, 'Erro ao consultar o CPF. Por favor, tente novamente.');
  }
});

bot.onText(/\/cnpj (.+)/, async (msg, match) => {
  const cnpj = match[1];
  try {
    const response = await axios.get(`http://eazybusca.000webhostapp.com/cnpj/${cnpj}/GuardPro`);
    const data = response.data;
    const message = `
**CNPJ:** ${formatBold(data.cnpj)}
**RAZAO SOCIAL:** ${formatBold(data.razaoSocial)}
ATIVIDADE: **${data.atividade}**
NOME: **${data.nome}**
LOGRADOURO: **${data.logradouro}**
BAIRRO: **${data.bairro}**
MUNICIPIO: **${data.municipio}**
UF: **${data.uf}**
CEP: **${data.cep}**
    `;
    bot.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
  } catch (error) {
    bot.sendMessage(msg.chat.id, 'Erro ao consultar o CNPJ. Por favor, tente novamente.');
  }
});

bot.onText(/\/cep (.+)/, async (msg, match) => {
  const cep = match[1];
  try {
    const response = await axios.get(`http://eazybusca.000webhostapp.com/cep/${cep}/GuardPro`);
    const data = response.data;
    const message = `
CEP: **${data.cep}**
LOGRADOURO: **${data.logradouro}**
BAIRRO: **${data.bairro}**
LOCALIDADE: **${data.localidade}**
UF: **${data.uf}**
    `;
    bot.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
  } catch (error) {
    bot.sendMessage(msg.chat.id, 'Erro ao consultar o CEP. Por favor, tente novamente.');
  }
});

bot.onText(/\/ip (.+)/, async (msg, match) => {
  const ip = match[1];
  try {
    const response = await axios.get(`http://eazybusca.000webhostapp.com/ip/${ip}/GuardPro`);
    const data = response.data;
    const message = `
**IP:** ${formatBold(data.ip)}
**COUNTRY:** ${formatBold(data.country)}
**REGION:** ${formatBold(data.region)}
**CITY:** ${formatBold(data.city)}
**POSTAL_CODE:** ${formatBold(data.postal_code)}
**LATITUDE:** ${formatBold(data.latitude)}
**LONGITUDE:** ${formatBold(data.longitude)}
    `;
    bot.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
  } catch (error) {
    bot.sendMessage(msg.chat.id, 'Erro ao consultar o IP. Por favor, tente novamente.');
  }
});

// Inicia o bot
bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id, 'Olá! Use os comandos /cpf, /cnpj, /cep ou /ip seguido do valor para realizar uma consulta.');
});
