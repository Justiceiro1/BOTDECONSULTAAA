requests
htmltext
python-telegram-bot
pycord==2.3.2
NewFunctionsPYC==1.2.0
node-telegram-bot-api